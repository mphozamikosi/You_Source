using Microsoft.VisualStudio.TestTools.UnitTesting;
using SortProject.Controller;
using SortProject.Model;

namespace SortProject.Tests
{
    [TestClass]
    public class SortTests
    {
        [TestInitialize]
        public void Init()
        {
        }
        [TestMethod]
        public void MainSortMethod_Test()
        {
            var stringModel = new StringModel
            {
                Strategy = StringModel.SortStrategy.BubbleSort,
                StringToSort = "TestString"
            };

            SortController.SortString(stringModel);
        }
        [TestMethod]
        public void CharArrToString_Test()
        {

            var testCharArry = new char[] { 'H', 'A', 'V', 's' };
            var convertedString = SortController.ConvertArrayToString(testCharArry);
        }
        [TestMethod]
        public void BubbleSort_Test()
        {
            SortController.BubbleSort("mphozamikosi");
        }
        [TestMethod]
        public void MergeSort_Test()
        {
             SortController.MergeSort("mphozamikosi");
        }

        [TestMethod]
        public void MergeArraySort_Test()
        {
            var testCharArry = new char[] { 'H', 'A', 'V', 's' };
            int left = 0;
            int right = testCharArry.Length - 1;
            SortController.SortArray(testCharArry, left, right);
        }
    }
}

﻿using System.Linq;
using static SortProject.Model.StringModel;

namespace SortProject.Controller
{
    public class SortController
    {
        public static string SortString(Model.StringModel stringModel)
        {
            return stringModel.Strategy == SortStrategy.BubbleSort ? BubbleSort(stringModel.StringToSort) : MergeSort(stringModel.StringToSort);
        }
        public static string BubbleSort(string inputString)
        {
            string temp;
            int l;

            var charArr = inputString.ToArray();

            l = charArr.Length;

            for (int i = 0; i < l; i++)
            {
                for (int j = 0; j < l - 1; j++)
                {
                    if (charArr[j].ToString().ToLower().CompareTo(charArr[j + 1].ToString().ToLower()) > 0)
                    {
                        temp = charArr[j].ToString();
                        charArr[j] = charArr[j + 1];
                        charArr[j + 1] = char.Parse(temp);
                    }
                }
            }

            return ConvertArrayToString(charArr);
        }

        public static string MergeSort(string inputString)
        {
            var charArr = inputString.ToArray();
            SortArray(charArr, 0, charArr.Length - 1);

            return ConvertArrayToString(charArr);
        }

        public static void SortArray(char[] array, int left, int right)
        {
            if (left < right)
            {
                int middle = left + (right - left) / 2;
                SortArray(array, left, middle);
                SortArray(array, middle + 1, right);
                MergeArray(array, left, middle, right);
            }
        }

        public static void MergeArray(char[] array, int left, int middle, int right)
        {
            var leftArrayLength = middle - left + 1;
            var rightArrayLength = right - middle;
            var leftTempArray = new char[leftArrayLength];
            var rightTempArray = new char[rightArrayLength];
            int i, j;
            for (i = 0; i < leftArrayLength; ++i)
                leftTempArray[i] = array[left + i];
            for (j = 0; j < rightArrayLength; ++j)
                rightTempArray[j] = array[middle + 1 + j];
            i = 0;
            j = 0;
            int k = left;
            while (i < leftArrayLength && j < rightArrayLength)
            {
                if (leftTempArray[i].ToString().ToLower().ToCharArray()[0] <= rightTempArray[j].ToString().ToLower().ToCharArray()[0])
                {
                    array[k++] = leftTempArray[i++];
                }
                else
                {
                    array[k++] = rightTempArray[j++];
                }
            }
            while (i < leftArrayLength)
            {
                array[k++] = leftTempArray[i++];
            }
            while (j < rightArrayLength)
            {
                array[k++] = rightTempArray[j++];
            }
        }

        public static string ConvertArrayToString(char[] charArr)
        {
            string convertedString = "";

            foreach (var character in charArr)
            {
                convertedString += character;
            }

            return convertedString;
        }
    }
}

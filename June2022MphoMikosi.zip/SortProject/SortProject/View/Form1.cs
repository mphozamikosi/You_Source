﻿using SortProject.Controller;
using SortProject.Model;
using System;
using System.Windows.Forms;

namespace SortProject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            errorInput.Text = "";
            errorStrategy.Text = "";
            if (inputString.Text == "")
            {
                errorInput.Text = "Input String is blank. Please fill in the text box.";
            }
            else if (sortTypes.SelectedItem == null)
            {
                errorStrategy.Text = "Sort Type is not selected. Please choose one sort strategy.";
            }
            else
            {
                var stringToSort = inputString.Text;
                var strategy = sortTypes.SelectedItem.ToString();
                var stringObject = new StringModel
                {
                    Strategy = strategy == "Bubble Sort" ? StringModel.SortStrategy.BubbleSort : StringModel.SortStrategy.MergeSort,
                    StringToSort = stringToSort
                };

                string sortedString = SortController.SortString(stringObject);

                lblOutput.Text = sortedString;
            }
        }



        private void Button2_Click(object sender, EventArgs e)
        {
            errorInput.Text = "";
            errorStrategy.Text = "";
            inputString.Text = "";
            lblOutput.Text = "";
        }
    }
}

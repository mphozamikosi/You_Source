﻿
namespace SortProject.Model
{
    public class StringModel
    {
        public enum SortStrategy { BubbleSort = 1, MergeSort = 2}
        public string StringToSort { get; set; }
        public SortStrategy Strategy { get; set; }
    }
}
